package com.altimetrik.workshop.domain;

public class Data {

	private Double temperatureHigh;
	private Double temperatureLow;
	private Long temperatureHighTime;
	private Long temperatureLowTime;
	private Long sunriseTime;
	private Long sunsetTime;
	
	public Double getTemperatureHigh() {
		return temperatureHigh;
	}
	public void setTemperatureHigh(Double temperatureHigh) {
		this.temperatureHigh = temperatureHigh;
	}
	public Double getTemperatureLow() {
		return temperatureLow;
	}
	public void setTemperatureLow(Double temperatureLow) {
		this.temperatureLow = temperatureLow;
	}
	public Long getTemperatureHighTime() {
		return temperatureHighTime;
	}
	public void setTemperatureHighTime(Long temperatureHighTime) {
		this.temperatureHighTime = temperatureHighTime;
	}
	public Long getTemperatureLowTime() {
		return temperatureLowTime;
	}
	public void setTemperatureLowTime(Long temperatureLowTime) {
		this.temperatureLowTime = temperatureLowTime;
	}
	public Long getSunriseTime() {
		return sunriseTime;
	}
	public void setSunriseTime(Long sunriseTime) {
		this.sunriseTime = sunriseTime;
	}
	public Long getSunsetTime() {
		return sunsetTime;
	}
	public void setSunsetTime(Long sunsetTime) {
		this.sunsetTime = sunsetTime;
	}
	
}
