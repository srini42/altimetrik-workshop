package com.altimetrik.workshop.helper;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;
import org.springframework.web.client.RestTemplate;

import com.altimetrik.workshop.domain.Weather;
import com.altimetrik.workshop.exception.WeatherException;

@Component
public class WeatherHelper {

	@Autowired
	RestTemplate restTemplate;
	
	protected static WeatherHelper instance;
	
	public static WeatherHelper instance(){
        if (instance == null){
        	instance = new WeatherHelper();
        }
        return instance;
    }
	
	public Weather getWeatherDetails(String url, String secretKey, String longitude, String latitude, Long epochTime) {
		
		Weather weather = null;
		ResponseEntity<Weather> responseEntity=null;
		url = url+secretKey+"/"+longitude+","+latitude;
		if(null != epochTime) {
			url = url + "," + epochTime; 
		}
		
		
		try {
			HttpHeaders headers = setJSONHeaders();
			HttpEntity<?> entity = new HttpEntity<>(headers);
			if(null == restTemplate) {
				restTemplate = new RestTemplate();
			}
			responseEntity = restTemplate.exchange(url, HttpMethod.GET, entity, Weather.class);
		}catch(Exception e) {
			throw new WeatherException(HttpStatus.SERVICE_UNAVAILABLE.toString(), e.getMessage());
		}
	
		return responseEntity.getBody();
	}
	
	
	public HttpHeaders setJSONHeaders() {
		// define the headers
		HttpHeaders headers = new HttpHeaders();
		headers.add("Accept", "application/x-www-form-urlencoded");
		headers.add("Content-Type", "application/x-www-form-urlencoded");
		return headers;
	}

}
