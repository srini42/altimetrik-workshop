package com.altimetrik.workshop.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.altimetrik.workshop.service.WeatherService;

@RestController
public class WeatherController {
	
	@Autowired
	WeatherService weatherService;

	@RequestMapping(method={RequestMethod.GET}, value="/v1/weather", produces=MediaType.APPLICATION_JSON_VALUE)
	  public ResponseEntity<String> getWeatherDetails(@RequestParam(value = "secretKey", required = false) String secretKey,
			  @RequestParam(value = "longitude", required = false) String longitude,
			  @RequestParam(value = "latitude", required = true) String latitude, @RequestParam(value = "epochTime", required = false) Long epochTime) {
	    
			String response = weatherService.getWeatherDetails(secretKey, longitude, latitude, epochTime);		
			return ResponseEntity.status(HttpStatus.CREATED).body(response);
		
	  }
}
