package com.altimetrik.workshop.domain;

public class Minutely {

}
