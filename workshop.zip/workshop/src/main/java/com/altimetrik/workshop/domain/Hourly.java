package com.altimetrik.workshop.domain;

public class Hourly {

}
