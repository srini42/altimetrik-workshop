package com.altimetrik.workshop.helper;

import org.joda.time.DateTime;

public class Test {

	public static void main(String[] args) {
		
		
		Long epochTime1 = new DateTime().now().minusYears(1).getMillis();
		System.out.println(epochTime1);
		System.out.println(new DateTime().now().getMillis());
	}
	
}
