package com.altimetrik.workshop.service;

public interface WeatherService {

	public String getWeatherDetails(String secretKey, String longitude, String latitude, Long epochTime);
	
}
