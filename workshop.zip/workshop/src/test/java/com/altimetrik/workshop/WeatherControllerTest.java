package com.altimetrik.workshop;

import static org.junit.Assert.assertTrue;

import org.junit.Test;

import com.altimetrik.workshop.domain.Weather;
import com.altimetrik.workshop.helper.WeatherHelper;

public class WeatherControllerTest {

	 @Test
	 public void testRequestCurrentWeather() throws Exception {
	        Weather result = WeatherHelper.instance()
	        		.getWeatherDetails("https://api.darksky.net/forecast/",
	        				"0b67f8f549800f7bdeccc85500ba9324", "42.335190", "-83.049190", null);
	        assertTrue("result is null!", result != null);
	        result = WeatherHelper.instance()
	        		.getWeatherDetails("https://api.darksky.net/forecast/",
	        				"0b67f8f549800f7bdeccc85500ba9324", "547.6067", "-122.3321", null);
	        		
	        assertTrue("result is null!", result == null);
	       
	    }
	
}
