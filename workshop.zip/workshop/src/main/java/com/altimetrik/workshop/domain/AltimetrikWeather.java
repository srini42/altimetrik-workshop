package com.altimetrik.workshop.domain;

public class AltimetrikWeather {

	private String Date;
	private String time;
	private Double temperature;
	private Long sunriseTime;
	private Long sunSetTime; 
	private Double temperatureHigh;
	private Long temperatureHighTime;
	private Double temperatureLow;
	private Long temperatureLowTime;
	
	public String getDate() {
		return Date;
	}
	public void setDate(String date) {
		Date = date;
	}
	public String getTime() {
		return time;
	}
	public void setTime(String time) {
		this.time = time;
	}
	public Double getTemperature() {
		return temperature;
	}
	public void setTemperature(Double temperature) {
		this.temperature = temperature;
	}
	public Long getSunriseTime() {
		return sunriseTime;
	}
	public void setSunriseTime(Long sunriseTime) {
		this.sunriseTime = sunriseTime;
	}
	public Long getSunSetTime() {
		return sunSetTime;
	}
	public void setSunSetTime(Long sunSetTime) {
		this.sunSetTime = sunSetTime;
	}
	public Double getTemperatureHigh() {
		return temperatureHigh;
	}
	public void setTemperatureHigh(Double temperatureHigh) {
		this.temperatureHigh = temperatureHigh;
	}
	public Long getTemperatureHighTime() {
		return temperatureHighTime;
	}
	public void setTemperatureHighTime(Long temperatureHighTime) {
		this.temperatureHighTime = temperatureHighTime;
	}
	public Double getTemperatureLow() {
		return temperatureLow;
	}
	public void setTemperatureLow(Double temperatureLow) {
		this.temperatureLow = temperatureLow;
	}
	public Long getTemperatureLowTime() {
		return temperatureLowTime;
	}
	public void setTemperatureLowTime(Long temperatureLowTime) {
		this.temperatureLowTime = temperatureLowTime;
	}
	
}
