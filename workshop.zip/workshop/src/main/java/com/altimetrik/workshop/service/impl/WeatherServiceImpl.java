package com.altimetrik.workshop.service.impl;

import java.util.LinkedList;
import java.util.List;
import java.util.stream.Collectors;

import org.dozer.DozerBeanMapper;
import org.dozer.loader.api.BeanMappingBuilder;
import org.joda.time.DateTime;
import org.joda.time.DateTimeZone;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import com.altimetrik.workshop.domain.AltimetrikWeather;
import com.altimetrik.workshop.domain.Currently;
import com.altimetrik.workshop.domain.Data;
import com.altimetrik.workshop.domain.Weather;
import com.altimetrik.workshop.helper.WeatherHelper;
import com.altimetrik.workshop.service.WeatherService;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;

@Component
public class WeatherServiceImpl implements WeatherService {

	@Autowired
	WeatherHelper weatherHelper;
	
	@Value("${weatherUrl}")
	String url;
	

	
	@Override
	public String getWeatherDetails(String secretKey, String longitude, String latitude, Long epochTime) {
		
		Gson gson = new GsonBuilder().serializeNulls().create(); 
		Weather todaysWeather = weatherHelper.getWeatherDetails(url, secretKey, longitude, latitude, null);
		epochTime = new DateTime().now().minusYears(1).getMillis()/1000;
		Weather lastYearWeather = weatherHelper.getWeatherDetails(url, secretKey, longitude, latitude, epochTime);
		List<Weather> list = new LinkedList<Weather>();
		if(null != todaysWeather)
			list.add(todaysWeather);
		if(null != lastYearWeather)
			list.add(lastYearWeather);
		return gson.toJson(getAltmetrikWeatherResources(list));
	}

	public List<AltimetrikWeather> getAltmetrikWeatherResources(List<Weather> weatherList) {
		
		return weatherList.stream().map(x->convertToAltimetrikWether(x))
							.collect(Collectors.toList());
		
	}
	
	public AltimetrikWeather convertToAltimetrikWether(Weather weather) {
		
		AltimetrikWeather altWeather = new AltimetrikWeather();
		Data data = weather.getDaily().getData().get(0);
		DozerBeanMapper dozerBeanMapper = new DozerBeanMapper();

		BeanMappingBuilder beanMappingBuilder = new BeanMappingBuilder() {
			@Override
			protected void configure() {
				mapping(Data.class, AltimetrikWeather.class)
						.fields("temperatureHigh", "temperatureHigh")
						.fields("temperatureLow", "temperatureLow")
						.fields("sunriseTime", "sunriseTime")
						.fields("sunSetTime", "sunSetTime")
						.fields("temperatureHigh", "temperatureHigh")
						.fields("temperatureHighTime", "temperatureHighTime")
						.fields("temperatureLow", "temperatureLow")
						.fields("temperatureLowTime", "temperatureLowTime");

			}
		};
		
		dozerBeanMapper.addMapping(beanMappingBuilder);
		altWeather = dozerBeanMapper.map(data, AltimetrikWeather.class);
		Currently currently = weather.getCurrently();
		Long time = currently.getTime() * 1000; 
		DateTime dateTime = new DateTime(time, DateTimeZone.forID("America/Detroit"));
		altWeather.setDate(dateTime.getMonthOfYear()+"-"+dateTime.getDayOfMonth()+"-"+dateTime.getYear());
		altWeather.setTime(dateTime.getHourOfDay()+":"+dateTime.getMinuteOfHour()+":"+dateTime.getSecondOfMinute());
		altWeather.setTemperature(currently.getTemperature());
		return altWeather;
	}
	
}
