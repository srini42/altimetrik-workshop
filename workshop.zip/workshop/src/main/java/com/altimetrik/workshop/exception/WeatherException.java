package com.altimetrik.workshop.exception;

public class WeatherException extends RuntimeException{
	
	private String httpcode;
	private String msg;
	
	public WeatherException(String httpcode, String msg) {
		this.httpcode = httpcode;
		this.msg = msg;
		toString();
	}
	
	public String toString() {
		return httpcode + ":" + msg;
	}

}
